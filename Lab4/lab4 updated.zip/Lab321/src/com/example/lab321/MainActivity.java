package com.example.lab321;

import java.net.URL;

import android.support.v7.app.ActionBarActivity;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings.PluginState;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends ActionBarActivity {
	String link ;
	String tf ;
	String TF ;
	String sq ;
	URL url;
	//WebView WB;
	TextView Result1, Result2;
	Button Generate, Recognize ,wv;
    EditText Trainfile, seqfile ;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		Trainfile = (EditText)findViewById(R.id.editText1);
		seqfile = (EditText)findViewById(R.id.editText2);
		Result1 = (TextView)findViewById(R.id.textView1);
		//Result2 = (TextView)findViewById(R.id.textView5);
		Generate = (Button)findViewById(R.id.button1);
		Recognize = (Button)findViewById(R.id.button2);
		wv = (Button)findViewById(R.id.button3);
		//WB = (WebView) findViewById(R.id.webView1);
		 tf = Trainfile.getText().toString();
		sq = seqfile.getText().toString();
		
		Generate.setOnClickListener(new View.OnClickListener() {
      
        
			@Override
			public void onClick(View v) {
				Log.i("onClick", "Generate is Called");
				tf = Trainfile.getText().toString();
				sq = seqfile.getText().toString();
			// TODO Auto-generated method stub
				new AsyncTask <Void, Void, String>()
				 { 
				@Override protected String doInBackground(Void... params) 
				{
					Log.i("doInBackground", "doInBackground is Called");
				 WebServiceRequestManager manager = new WebServiceRequestManager();
				String url = "http://134.193.136.147:8080/HMMWS/jaxrs/generic/TestFileOperation/-home-group9-"+tf+".txt/-home-group9-"+sq+".seq";
				 
				 return manager.getMethod(url); 
				 
				} 
				@Override protected void onPostExecute(String PrintResult) { 
				super.onPostExecute(PrintResult); 
				//System.out.println(PrintResult);
				Result1.setText(PrintResult);
				//SaveFile sf =new SaveFile();
				//sf.SaveData(PrintResult);
				 
				}
				 }
				.execute();
			
			}});
		
		
		wv.setOnClickListener(new View.OnClickListener() {
		      
	        
		
			@Override
			public void onClick(View v) {
				Log.i("onClick", "Webview is Called");
			// TODO Auto-generated method stub
		 
				tf = Trainfile.getText().toString();
				sq = seqfile.getText().toString();
				String url = "http://134.193.136.147:8080/HMMWS/jaxrs/generic/TestFileOperation/-home-group9-"+tf+".txt/-home-group9-"+sq+".seq";
				Uri uriUrl = Uri.parse(url);
				Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriUrl);
				startActivity(launchBrowser);
			
				
			}});
		
		
		Recognize.setOnClickListener(new View.OnClickListener() {
		      
	        
			@Override
			public void onClick(View v) {
				Log.i("onClick", "Recognize is Called");
			// TODO Auto-generated method stub
				sq = seqfile.getText().toString();
				new AsyncTask <Void, Void, String>()
				 { 
				@Override protected String doInBackground(Void... params) 
				{
					Log.i("doInBackground", "doInBackground is Called");
				 WebServiceRequestManager manager = new WebServiceRequestManager();
				String url = "http://134.193.136.147:8080/HMMWS/jaxrs/generic/HMMTrainingTest/-home-group9-TrainingPunch.seq:-home-group9-TrainingRL.seq:-home-group9-TrainingLR.seq/punch:ltor:rtol/-home-group9-"+sq+".seq";
				 
				 return manager.getMethod(url); 
				 
				} 
				@Override protected void onPostExecute(String PrintResult) { 
				super.onPostExecute(PrintResult); 
				System.out.println(PrintResult);
				Result1.setText(PrintResult);
				SaveFile sf =new SaveFile();
				sf.SaveData(PrintResult);
				 
				}
				 }
				.execute();
			
			}});
		
		

		if (savedInstanceState == null) {
			getSupportFragmentManager().beginTransaction()
					.add(R.id.container, new PlaceholderFragment()).commit();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main, container,
					false);
			return rootView;
		}
	}
	
}
