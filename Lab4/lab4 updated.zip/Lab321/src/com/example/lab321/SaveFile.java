package com.example.lab321;

import java.io.File;
import java.io.FileOutputStream;
import android.os.Environment;
import android.util.Log;

public class SaveFile {
	
	public void SaveData(String string) {
	      // Log.i("string", string);
		Log.i( "onClick"," Save file Called");
	        File sdCard = Environment.getExternalStorageDirectory();
	        File directory = new File (sdCard.getAbsolutePath() + "/Data");
	        if(!directory.exists())
	        directory.mkdirs();
	        String fname = "GireshRecognition.txt";
	        File file = new File (directory, fname);
	        
	        try {
	            if(!file.exists())
	                file.createNewFile();
	               FileOutputStream out = new FileOutputStream(file,true);
	               out.write(string.getBytes());
	               out.flush();
	               out.close();

	        } catch (Exception e) {
	               e.printStackTrace();
	        }
	    }
	

}
