package com.example.lab321;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.util.Log;

public class WebServiceRequestManager {
	
	
	
String PrintResult;
	 
	

	public String getMethod(String url) { 
		
		try {
		Log.i("string getmethod", "string get method is called");
		HttpClient httpclient = new DefaultHttpClient(); 
		HttpResponse response = httpclient.execute(new HttpGet(url));
		//String responseString = null; 
		String result = "";
		BufferedReader reader =new BufferedReader (new InputStreamReader(response.getEntity().getContent()));     
		
		String Value = "";
		//String PrintResult = "";
		while ((Value =reader.readLine())!=null)
		{
			result += Value + "\n";
		PrintResult = result;
		
		}
		} catch (ClientProtocolException e){
			e.printStackTrace();
			PrintResult = "Table Name Already exists or Table not found";
		    
		
	} catch (IOException e) {
		e.printStackTrace();
		PrintResult = "Input File Not Found";
		
	}
		
		/*try { 
			response = httpclient.execute(new HttpGet(url)); 
			
			StatusLine statusLine = response.getStatusLine();
			System.out.println("Status line" +statusLine);
			//Toast.makeText(getApplicationContext(), statusLine, Toast.LENGTH_LONG).show();
			if (statusLine.getStatusCode() == HttpStatus.SC_OK) { 
				ByteArrayOutputStream out = new ByteArrayOutputStream(); 
				response.getEntity().writeTo(out); 
				out.close(); 
				responseString = out.toString(); 
				System.out.println("Response :" +responseString);
				} 
			else 
				{ 
					// Closes the connection. 
					response.getEntity().getContent().close(); 
					responseString = "closed";
					System.out.println("Response :" +responseString);
					//Toast.makeText(getApplicationContext(), statusLine, Toast.LENGTH_LONG).show();
					throw new IOException(statusLine.getReasonPhrase()); 
					}
			} catch (ClientProtocolException e) { 
				// TODO Handle problems.. 
				} catch (IOException e) { 
					// TODO Handle problems.. 
					}*/ 
		//return responseString; 
		return PrintResult; 	
	} 
	           


}
