package com.example.lab32;



import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;

import net.neoremind.sshxcute.core.ConnBean;
import net.neoremind.sshxcute.core.SSHExec;
import net.neoremind.sshxcute.exception.TaskExecFailException;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;







import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Build;

public class MainActivity extends ActionBarActivity {
	
	//String URL ;
	TextView Result;
	Button Create, Insert, Retrieve, Delete ;
	//EditText TableName;
	//String TN;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		Result = (TextView)findViewById(R.id.textView1);
	    //TableName	= (EditText)findViewById(R.id.editText1);
			
	    //TN = TableName.getText().toString();
	    //URL = "http://134.193.136.147:8080/HbaseWS/jaxrs/generic/hbaseCreate/"+TableName+"/GpsData:TimeStamp:AccelData";
		Retrieve = (Button)findViewById(R.id.button1);
		Retrieve.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Log.i("onClick", "Retrieve Called");
			// TODO Auto-generated method stub
				new AsyncTask <Void, Void, String>()
				 { 
				@Override protected String doInBackground(Void... params) 
				{
					Log.i("doInBackground", "doInBackground is Called");
				 WebServiceRequestManager manager = new WebServiceRequestManager();
				 
				 return manager.getMethod("http://134.193.136.147:8080/HbaseWS/jaxrs/generic/hbaseRetrieveAll/AppleBigData3"); 
				 
				 
				} 
				@Override protected void onPostExecute(String PrintResult) { 
				super.onPostExecute(PrintResult); 
				System.out.println(PrintResult);
				Result.setText(PrintResult);
				 
				}
				 }
				.execute();
			
			}});
		
		
		Delete = (Button)findViewById(R.id.button4);
		Delete.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Log.i("onClick", "delete Called");
			// TODO Auto-generated method stub
				new AsyncTask <Void, Void, String>()
				 { 
				@Override protected String doInBackground(Void... params) 
				{
					Log.i("doInBackground", "doInBackground is Called");
				 WebServiceRequestManager manager = new WebServiceRequestManager();
				 return manager.getMethod("http://134.193.136.147:8080/HbaseWS/jaxrs/generic/hbasedelete1/AppleBigData3"); 
				} 
				@Override protected void onPostExecute(String PrintResult) { 
				super.onPostExecute(PrintResult); 
				Result.setText(PrintResult);
				System.out.println(PrintResult); 
				 
				}
				 }
				.execute();
			}});
		
		
		
		
		Insert = (Button)findViewById(R.id.button3);
		Insert.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Log.i("onClick", "insert clicked Called");
			// TODO Auto-generated method stub
				
				
				
				new AsyncTask <Void, Void, String>()
				 { 
				@Override protected String doInBackground(Void... params) 
				{
					Log.i("doInBackground", "doInBackground is Called");
				 WebServiceRequestManager manager = new WebServiceRequestManager();
				 return manager.getMethod("http://134.193.136.147:8080/HbaseWS/jaxrs/generic/hbaseInsert/AppleBigData3/-home-group9-sensortag.txt/GpsData:TimeStamp:AccelData"); 
				} 
				@Override protected void onPostExecute(String PrintResult) { 
				super.onPostExecute(PrintResult); 
				Result.setText("Status :"+PrintResult);
				System.out.println(PrintResult); 
								
				}
				 }
				.execute();
			}});
		
		
		Create = (Button)findViewById(R.id.button2);
		Create.setOnClickListener(new View.OnClickListener() {
           
			@Override
			public void onClick(View v) {
				Log.i("onClick", "Create click Called");
			// TODO Auto-generated method stub
				
			
				
				new AsyncTask <Void, Void, String>()
				 { 
				@Override protected String doInBackground(Void... params) 
				{
					Log.i("doInBackground", "doInBackground is Called");
				 WebServiceRequestManager manager = new WebServiceRequestManager();
				 return manager.getMethod("http://134.193.136.147:8080/HbaseWS/jaxrs/generic/hbaseCreate/AppleBigData3/GpsData:TimeStamp:AccelData"); 
				} 
				@Override protected void onPostExecute(String PrintResult) { 
				super.onPostExecute(PrintResult); 
				Result.setText("Status :"+PrintResult);
				System.out.println(PrintResult); 
				
				Result.setText(PrintResult);
				}
				 }
				.execute();
			}});
		
		
	
		
		if (savedInstanceState == null) {
			getSupportFragmentManager().beginTransaction()
					.add(R.id.container, new PlaceholderFragment()).commit();
		}
	}

	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main, container,
					false);
			return rootView;
		}

	}
}
	

	
		



























